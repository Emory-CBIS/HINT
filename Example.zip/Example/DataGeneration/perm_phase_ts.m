% this function returns a new time series whose phases are permuted
function perm_phase_ts=perm_phase_ts(ts)

y=fft(ts);
m=abs(y);
phase=(angle(y));

rand_perm=randperm(length(phase));
phase_perm=phase(rand_perm);

y1=complex(m.*cos(phase_perm),m.*sin(phase_perm));

perm_phase_ts=real(ifft(y1));
