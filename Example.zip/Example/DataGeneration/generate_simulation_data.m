function [ output_args ] = generate_simulation_data( HINTpath, N, q, maskfl, datadir )
%generate_simulation_data - function to generate the simulation data used
%in the HINT manuscript

addpath(genpath(HINTpath))


outpath = datadir;
mkdir(outpath)
mask = load_nii(maskfl);
validVoxels = find( mask.img > 0 );
V = size(validVoxels, 1);
locs_selec = find(mask.img > 0);
p=2;
source_intensity =  3;

load('beta.mat');
beta = beta(:, 1:2, :);
load('A.mat');
load('S.mat');

% Each base map
S1 = S(1,:);
S2 = S(2,:);
S3 = S(3,:);

% save beta A and s0 as .m files
emptyImage = zeros( size(mask.img) );
for i=1:q
     emptyImage(locs_selec) = squeeze( S(i,:) );
     new_image = make_nii( emptyImage );
     save_nii( new_image, [fullfile(outpath, 'S0_'), num2str(i) '.nii'] )
end
for i=1:p
    for j = 1:q
     emptyImage(locs_selec) = squeeze( beta(i,j,:) );
     new_image = make_nii( emptyImage );
     save_nii( new_image, [fullfile(outpath, 'BETA_cov_'), num2str(i) '_ic_' num2str(j) '.nii'] )
    end
end

%beta0=beta; clear beta;
A0=A; clear A;
S0=S; clear S;

beta0 = beta;

p = 2;
time_num = 200;

epsilon1 = 0.03;
epsilon2 = 0.03;


sigma1 =  0.5; 
sigma2 = [0.5, 0.5, 0.5];


  [X, sbj_IC, M_sim, data_sim]...
    = SimuDataGenNew(N, q, p, V, beta0, A0, S0, time_num, sigma1, sigma2, 0);

vxl = size(mask.img);
imgtemp = make_nii(NaN([vxl, time_num]),...
                   [], [], 16, 'hc-ICA simulation');

subjnames = zeros(N, 1);               
for i=1:N
    for t=1:time_num
        imgmat3D = NaN(vxl);
        imgmat3D(locs_selec) =  data_sim( time_num*(i-1)+t ,:);
        imgtemp.img(:, :, :, t) = imgmat3D;
    end
    savename = [fullfile(outpath, 'subj'), int2str(i), '.nii'];
    save_nii(imgtemp, savename);
end

imgtemp = make_nii(NaN(vxl),...
                   [], [], 16, 'hc-ICA simulation');
imgtemp.img(locs_selec)=1;
save_nii(imgtemp, ['maskSimu.nii']);

%Subject = {'subj1.nii', 'subj2.nii', 'subj3.nii', 'subj4.nii', 'subj5.nii',...
%    'subj6.nii','subj7.nii','subj8.nii','subj9.nii','subj10.nii'}';

Subject = cell(N, 1);

Score = X(:, 1);
Score = Score - mean(Score);
GroupTemp = X(:, 2);
Group = Subject;
for i = 1:N
    Subject{i} = ['subj' num2str(i) '.nii'];
    if GroupTemp(i) == 1
        Group{i} = 'Trt';
    else
        Group{i} = 'Ctrl';
    end
end
Gender = [0, 0, 1, 0, 1]';

tt = table(Subject, Score, Group, Gender);

writetable(tt, fullfile(outpath, 'Covariates.csv'));

end

