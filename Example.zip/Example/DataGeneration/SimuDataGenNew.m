function [X, sbj_IC, M_sim, data_sim]...
    = SimuDataGenNew(N, q, p, V, beta0, A0, S0, time_num, sigma1, sigma2, rho)
%%% Simulation data generation 
%%% Preprocessing Done within the Program
%%% --------------------- Change from here for each round of the simulation-------------%%%
%%% grp_IC, sbj_IC: all truth


%%%%%% Covariate generation %%%%%%%%%%%%%%%%%%
%X = mvnrnd([0, 0], [1, rho; rho, 1 ], N);
%X = rand([N, 1]) > 0.5;
X = zeros(N, p);
X = mvnrnd([0, 0], [1, rho; rho, 1 ], N);
X(:, 1) = rand(N, 1);
needsgen = 1;
while  needsgen == 1
    X(:, 2) = rand([N, 1]) > 0.5;
    if sum(X(:, 2) < 5 & sum(X(:, 2)) > 0)
        needsgen = 0;
    else
        disp('RESETTING!!!')
    end
end

%X(:,p) = 1*((X(:, p)>0));

%%%% Generate subject specific IC
%%% generate IC specific variances
var2 = zeros(V, N, q);
for l=1:q
    var2(:,:,l) = sigma2(l)*randn(V, N); %% generate variance for each subject at each voxel
end;

sbj_IC = zeros(V, q, N);
if q > 1
for l = 1:q
    for i = 1:N
        sbj_IC(:,l,i) = S0(l, :) +(X(i, :)*squeeze(beta0(:,l,:))) + var2(:,i,l)';
    end;
end;
else
    for l = 1:q
    for i = 1:N
        sbj_IC(:,l,i) = S0(l, :) + X(i, :)*squeeze(beta0(:,l,:))' + var2(:,i,l)';
    end;
end;
end
%tt=reshape(sbj_IC(:,3,10),vxl);
%imagesc(tt(:,:,1));

%%%% Merge with time series and and var1 %%%%
%generate Y_i  TN*V
T = time_num;

for i=1:N
    clear temp;
    for l=1:q
        if (l==1)
            temp=perm_phase_ts(A0(1:time_num,l));
        else
            temp=[temp  perm_phase_ts(A0(1:time_num,l))];
        end
    end % end for l=1:q 
    if (i==1)
        M_sim=temp;
    else
        M_sim=[M_sim; temp]; 
    end 
end

if q > 1

for i=1:N
    if (i==1)      
        data_sim = M_sim( (i*T-T+1): i*T , :) * sbj_IC(:,:,i)'  ;  %% data_sim T*V
    else
        data_sim =[data_sim; M_sim( (i*T-T+1): i*T, :) * sbj_IC(:,:,i)' ];
    end    
end

else
    
    for i=1:N
        disp(i)
        if (i==1)      
            data_sim = M_sim( (i*T-T+1): i*T , :) * sbj_IC(:,:,i)'  ;  %% data_sim T*V
        else
            data_sim =[data_sim; M_sim( (i*T-T+1): i*T, :) * sbj_IC(:,:,i)' ];
        end    
    end
    
end

%%% add in noise
data_sim = data_sim + sigma1*randn(size(data_sim));
%%% Output data : NT * V
end





