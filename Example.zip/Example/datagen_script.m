%%%% Script to generate simulation data

%% User Input

% Example folder location
SMpath = '/Users/joshlukemire/Documents/Research/cbis/hcICA/manuscript/Example';

% Specify the HINT folder location
HINTpath = '/Users/joshlukemire/repos/HINT';

% Seed for the datageneration and analysis
rng(12342048)


%% The remainder of this script will generate data
datadir = fullfile(SMpath, 'Data');
outdir = fullfile(SMpath, 'Results');
q= 2;
N = 5;
numberOfPCs = 6;
maskf = fullfile(SMpath, 'DataGeneration', 'maskSimu.nii');
covf = fullfile(datadir, 'Covariates.csv');
prefix = 'replication';
maxit = 100;
epsilon1 = 0.001;
epsilon2 = 0.1;

addpath(fullfile(HINTpath, 'src'))

% Generate the simulation data
addpath(fullfile(SMpath, 'DataGeneration'))
generate_simulation_data(HINTpath, N, q, maskf, datadir)